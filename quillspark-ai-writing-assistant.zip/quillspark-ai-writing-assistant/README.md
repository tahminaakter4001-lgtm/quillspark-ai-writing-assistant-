# QuillSpark — AI Writing Assistant

A lightweight, responsive writing workspace starter built with plain HTML, CSS, and JavaScript.


## Features in this starter
- Responsive writing dashboard
- Tool navigation: Write, Rewrite, Polish, Summarize, Translate, Terminology Audit
- Tone and language selectors (UI starter controls)
- Word count, clear, and copy-result controls
- Demo-only result previews (no AI/API is connected yet)

## Run locally
Open `index.html` in a browser. No build tools required.

## Publish with GitHub Pages
1. Push these files to your repository's `main` branch.
2. Open repository **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select `main` and `/ (root)`, then Save.
5. Wait for the deployment status and open the Pages URL shown in Settings.

## Connect an AI backend
This starter is frontend-only. To add real AI writing, connect a backend endpoint. Do not put secret API keys in browser-side JavaScript or commit them to GitHub.

